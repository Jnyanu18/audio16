echo "# bandgroup_home" >> README.md
git init

git add README.md

git commit -m "first commit"
git branch -M main
git remote add origin https://github.com/Himanshu4732/bandgroup_home.git
git push -u origin main
